const $ = id => document.getElementById(id);

// Restore saved values
chrome.storage.local.get(["url", "key"], ({ url, key }) => {
  if (url) $("url").value = url;
  if (key) $("key").value = key;
});

$("connect").addEventListener("click", async () => {
  const url = $("url").value.trim();
  const key = $("key").value.trim();
  const status = $("status");

  if (!url || !key) {
    show(status, "Please enter both the MCP URL and API key.", false);
    return;
  }

  $("connect").textContent = "Connecting…";
  $("connect").disabled = true;

  // Derive OpenAPI URL from MCP URL
  const base = url.replace(/\/mcp\/?$/, "");
  const openapiUrl = `${base}/openapi.json`;

  try {
    const resp = await fetch(openapiUrl, {
      headers: { "Authorization": `Bearer ${key}` },
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const schema = await resp.json();
    const toolCount = Object.keys(schema.paths ?? {}).length;

    await chrome.storage.local.set({ url, key });

    // Notify the active Gemini tab to reload tools
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: "SKILLS_UPDATED" });

    show(status, `Connected — ${toolCount} tool${toolCount !== 1 ? "s" : ""} loaded.`, true);
  } catch (err) {
    show(status, `Failed: ${err.message}`, false);
  } finally {
    $("connect").textContent = "Connect";
    $("connect").disabled = false;
  }
});

function show(el, msg, ok) {
  el.textContent = msg;
  el.className = ok ? "ok" : "err";
  el.style.display = "block";
}
