// Content script — injects the Skills panel into gemini.google.com.

(function () {
  if (document.getElementById("skills-portal-panel")) return; // already injected

  // ── State ────────────────────────────────────────────────────────────────────
  let tools = []; // [{ skill, tool, summary, schema }]
  let selectedTool = null;
  let panelVisible = true;
  let lastCalledSkill = "";
  let lastCalledTool = "";

  // ── Panel DOM ─────────────────────────────────────────────────────────────────
  const panel = document.createElement("div");
  panel.id = "skills-portal-panel";
  Object.assign(panel.style, {
    position: "fixed", bottom: "24px", right: "24px", zIndex: "999999",
    width: "300px", background: "#fff", borderRadius: "10px",
    boxShadow: "0 4px 20px rgba(0,0,0,0.18)", fontFamily: "system-ui,sans-serif",
    fontSize: "13px", overflow: "hidden", border: "1px solid #e0e0e0",
  });

  panel.innerHTML = `
    <div id="sp-header" style="
      display:flex; align-items:center; justify-content:space-between;
      padding:10px 14px; background:#1a73e8; color:#fff; cursor:pointer;
    ">
      <span style="font-weight:600; font-size:14px;">⚡ Skills</span>
      <span id="sp-toggle" style="font-size:11px; opacity:0.85;">▾ hide</span>
    </div>
    <div id="sp-body" style="padding:12px;">
      <input id="sp-search" type="text" placeholder="Search tools…" style="
        width:100%; box-sizing:border-box; padding:6px 8px; border:1px solid #ccc;
        border-radius:5px; font-size:12px; margin-bottom:8px;
      ">
      <select id="sp-picker" style="
        width:100%; padding:6px 8px; border:1px solid #ccc; border-radius:5px;
        font-size:12px; margin-bottom:10px;
      ">
        <option value="">— select a tool —</option>
      </select>
      <div id="sp-summary" style="color:#555; font-size:11px; margin-bottom:8px; display:none;"></div>
      <div id="sp-fields"></div>
      <button id="sp-run" style="
        display:none; width:100%; padding:7px; background:#1a73e8; color:#fff;
        border:none; border-radius:5px; font-size:13px; cursor:pointer; font-weight:600; margin-top:4px;
      ">▶ Run</button>
      <div id="sp-result" style="margin-top:10px; display:none;">
        <div id="sp-result-text" style="
          background:#f8f9fa; border:1px solid #e0e0e0; border-radius:5px;
          padding:8px; font-size:11px; max-height:160px; overflow-y:auto; white-space:pre-wrap; word-break:break-word;
        "></div>
        <div style="display:flex; gap:6px; margin-top:6px;">
          <button id="sp-copy" style="
            flex:1; padding:5px; background:#fff; border:1px solid #ccc;
            border-radius:5px; font-size:12px; cursor:pointer;
          ">📋 Copy</button>
          <button id="sp-insert" style="
            flex:1; padding:5px; background:#fff; border:1px solid #ccc;
            border-radius:5px; font-size:12px; cursor:pointer;
          ">⌨ Insert</button>
        </div>
        <div id="sp-feedback" style="display:none; margin-top:6px; text-align:center; font-size:11px; color:#888;">
          Helpful?
          <button id="sp-thumb-up" style="background:none; border:none; cursor:pointer; font-size:15px; padding:1px 5px;">👍</button>
          <button id="sp-thumb-down" style="background:none; border:none; cursor:pointer; font-size:15px; padding:1px 5px;">👎</button>
        </div>
      </div>
      <div id="sp-status" style="margin-top:8px; font-size:11px; color:#888; text-align:center;"></div>
    </div>
  `;

  document.body.appendChild(panel);

  // ── Element refs ──────────────────────────────────────────────────────────────
  const header   = panel.querySelector("#sp-header");
  const body     = panel.querySelector("#sp-body");
  const toggle   = panel.querySelector("#sp-toggle");
  const search   = panel.querySelector("#sp-search");
  const picker   = panel.querySelector("#sp-picker");
  const summary  = panel.querySelector("#sp-summary");
  const fields   = panel.querySelector("#sp-fields");
  const runBtn   = panel.querySelector("#sp-run");
  const result   = panel.querySelector("#sp-result");
  const resultTx = panel.querySelector("#sp-result-text");
  const copyBtn    = panel.querySelector("#sp-copy");
  const insertBtn  = panel.querySelector("#sp-insert");
  const feedbackRow= panel.querySelector("#sp-feedback");
  const thumbUp    = panel.querySelector("#sp-thumb-up");
  const thumbDown  = panel.querySelector("#sp-thumb-down");
  const status     = panel.querySelector("#sp-status");

  // ── Toggle visibility ─────────────────────────────────────────────────────────
  header.addEventListener("click", () => {
    panelVisible = !panelVisible;
    body.style.display = panelVisible ? "block" : "none";
    toggle.textContent = panelVisible ? "▾ hide" : "▸ show";
  });

  // ── Load tools from OpenAPI schema ────────────────────────────────────────────
  function loadTools() {
    setStatus("Loading tools...");
    chrome.runtime.sendMessage({ type: "LOAD_TOOLS" }, (response) => {
      if (!response) {
        setStatus("No response from background service worker.");
        return;
      }
      if (response.ok) {
        const schema = response.schema;
        tools = parsePaths(schema);
        populatePicker(tools);
        setStatus(tools.length ? "" : "No tools found.");
      } else {
        setStatus(`Could not load tools: ${response.error}`);
      }
    });
  }

  function parsePaths(schema) {
    return Object.entries(schema.paths ?? {}).map(([path, def]) => {
      // path: /api/{skill}/{tool}
      const parts = path.split("/").filter(Boolean); // ["api", "skill", "tool"]
      const skill = parts[1];
      const tool  = parts[2];
      const post  = def.post ?? {};
      const inputSchema = post.requestBody?.content?.["application/json"]?.schema ?? {};
      return { skill, tool, summary: post.summary ?? "", schema: inputSchema };
    });
  }

  function populatePicker(list) {
    picker.innerHTML = '<option value="">— select a tool —</option>';
    list.forEach(({ skill, tool, summary: s }) => {
      const opt = document.createElement("option");
      opt.value = `${skill}/${tool}`;
      opt.textContent = `${skill} / ${tool}`;
      opt.title = s;
      picker.appendChild(opt);
    });
  }

  // ── Search filter ─────────────────────────────────────────────────────────────
  search.addEventListener("input", () => {
    const q = search.value.toLowerCase();
    const filtered = q ? tools.filter(t =>
      `${t.skill} ${t.tool} ${t.summary}`.toLowerCase().includes(q)
    ) : tools;
    populatePicker(filtered);
    picker.value = "";
    clearToolUI();
  });

  // ── Tool selection ────────────────────────────────────────────────────────────
  picker.addEventListener("change", () => {
    const val = picker.value;
    if (!val) { clearToolUI(); return; }
    const [skill, tool] = val.split("/");
    selectedTool = tools.find(t => t.skill === skill && t.tool === tool) ?? null;
    if (!selectedTool) return;
    renderFields(selectedTool);
  });

  function clearToolUI() {
    selectedTool = null;
    fields.innerHTML = "";
    summary.style.display = "none";
    runBtn.style.display = "none";
    result.style.display = "none";
    feedbackRow.style.display = "none";
  }

  function renderFields(toolDef) {
    fields.innerHTML = "";
    result.style.display = "none";

    if (toolDef.summary) {
      summary.textContent = toolDef.summary;
      summary.style.display = "block";
    } else {
      summary.style.display = "none";
    }

    const props = toolDef.schema.properties ?? {};
    const required = new Set(toolDef.schema.required ?? []);

    Object.entries(props).forEach(([name, prop]) => {
      const wrapper = document.createElement("div");
      wrapper.style.marginBottom = "7px";

      const lbl = document.createElement("label");
      lbl.textContent = name + (required.has(name) ? " *" : "");
      lbl.htmlFor = `sp-field-${name}`;
      Object.assign(lbl.style, { display: "block", fontWeight: "600", marginBottom: "2px", fontSize: "11px", color: "#555" });

      const inp = document.createElement("input");
      inp.id = `sp-field-${name}`;
      inp.dataset.field = name;
      inp.placeholder = prop.description ?? prop.type ?? "";
      if (prop.default !== undefined) inp.value = String(prop.default);
      Object.assign(inp.style, {
        width: "100%", boxSizing: "border-box", padding: "5px 8px",
        border: "1px solid #ccc", borderRadius: "5px", fontSize: "12px",
      });

      wrapper.appendChild(lbl);
      wrapper.appendChild(inp);
      fields.appendChild(wrapper);
    });

    runBtn.style.display = "block";
  }

  // ── Run tool ──────────────────────────────────────────────────────────────────
  runBtn.addEventListener("click", async () => {
    if (!selectedTool) return;
    const props = selectedTool.schema.properties ?? {};
    const args = {};
    Object.keys(props).forEach(name => {
      const inp = fields.querySelector(`[data-field="${name}"]`);
      if (!inp || inp.value === "") return;
      // Coerce to number if the schema says so
      args[name] = props[name].type === "number" || props[name].type === "integer"
        ? Number(inp.value)
        : props[name].type === "boolean"
          ? inp.value === "true"
          : inp.value;
    });

    runBtn.textContent = "Running…";
    runBtn.disabled = true;
    result.style.display = "none";
    setStatus("");

    const calledSkill = selectedTool.skill;
    const calledTool  = selectedTool.tool;

    chrome.runtime.sendMessage(
      { type: "CALL_TOOL", skill: calledSkill, tool: calledTool, args },
      (response) => {
        runBtn.textContent = "▶ Run";
        runBtn.disabled = false;
        if (!response) {
          setStatus("No response from background service worker.");
          return;
        }
        if (response.ok) {
          const text = typeof response.result === "string"
            ? response.result
            : JSON.stringify(response.result, null, 2);
          resultTx.textContent = text;
          result.style.display = "block";
          lastCalledSkill = calledSkill;
          lastCalledTool  = calledTool;
          feedbackRow.style.display = "block";
          thumbUp.textContent   = "👍";
          thumbDown.textContent = "👎";
          setStatus("");
        } else {
          setStatus(`Error: ${response.error}`);
        }
      }
    );
  });

  // ── Feedback thumbs ───────────────────────────────────────────────────────────
  function submitThumb(rating) {
    const skill = lastCalledSkill;
    const tool  = lastCalledTool;
    if (!skill) return;
    thumbUp.textContent   = rating === 5 ? "✓👍" : "👍";
    thumbDown.textContent = rating === 1 ? "✓👎" : "👎";
    thumbUp.disabled   = true;
    thumbDown.disabled = true;
    chrome.runtime.sendMessage(
      { type: "CALL_TOOL", skill: "feedback_skill", tool: "submit_feedback",
        args: { skill, tool, rating } },
      () => {
        setTimeout(() => {
          thumbUp.disabled   = false;
          thumbDown.disabled = false;
        }, 1500);
      }
    );
  }

  thumbUp.addEventListener("click",   () => submitThumb(5));
  thumbDown.addEventListener("click", () => submitThumb(1));

  // ── Copy / Insert ─────────────────────────────────────────────────────────────
  copyBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(resultTx.textContent).then(() => {
      copyBtn.textContent = "✓ Copied";
      setTimeout(() => { copyBtn.textContent = "📋 Copy"; }, 1500);
    });
  });

  insertBtn.addEventListener("click", () => {
    const text = resultTx.textContent;
    // Try multiple selectors for Gemini's input area (may change with redesigns)
    const selectors = [
      "div.ql-editor[contenteditable='true']",
      "rich-textarea [contenteditable='true']",
      "[contenteditable='true'][aria-label]",
      "textarea",
    ];
    let input = null;
    for (const sel of selectors) {
      input = document.querySelector(sel);
      if (input) break;
    }

    if (input) {
      input.focus();
      if (input.tagName === "TEXTAREA") {
        input.value = (input.value ? input.value + "\n\n" : "") + text;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      } else {
        // contenteditable
        const sel = window.getSelection();
        sel.selectAllChildren(input);
        sel.collapseToEnd();
        document.execCommand("insertText", false, (input.textContent ? "\n\n" : "") + text);
      }
      insertBtn.textContent = "✓ Inserted";
      setTimeout(() => { insertBtn.textContent = "⌨ Insert"; }, 1500);
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(text);
      insertBtn.textContent = "📋 Copied (insert unavailable)";
      setTimeout(() => { insertBtn.textContent = "⌨ Insert"; }, 2000);
    }
  });

  // ── Helpers ───────────────────────────────────────────────────────────────────
  function setStatus(msg) {
    status.textContent = msg;
    status.style.display = msg ? "block" : "none";
  }

  // ── Listen for config updates from popup ──────────────────────────────────────
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "SKILLS_UPDATED") loadTools();
  });

  // ── Initial load ──────────────────────────────────────────────────────────────
  loadTools();
})();
