// Service worker — proxies tool calls from content.js to the Cloudflare REST API.
// Handles messages: { type: "CALL_TOOL", skill, tool, args } and { type: "LOAD_TOOLS" }

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "CALL_TOOL") {
    (async () => {
      const { url, key } = await chrome.storage.local.get(["url", "key"]);
      if (!url || !key) {
        sendResponse({ ok: false, error: "Not configured — open the extension popup first." });
        return;
      }

      // url is the MCP URL (ends with /mcp). Derive REST base by stripping /mcp.
      const base = url.replace(/\/mcp\/?$/, "");
      const endpoint = `${base}/api/${message.skill}/${message.tool}`;

      try {
        const resp = await fetch(endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${key}`,
          },
          body: JSON.stringify(message.args ?? {}),
        });

        const text = await resp.text();
        if (!resp.ok) {
          sendResponse({ ok: false, error: `HTTP ${resp.status}: ${text}` });
          return;
        }

        let result;
        try { result = JSON.parse(text); } catch { result = text; }
        sendResponse({ ok: true, result });
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true; // keep message channel open for async response
  } else if (message.type === "LOAD_TOOLS") {
    (async () => {
      const { url, key } = await chrome.storage.local.get(["url", "key"]);
      if (!url || !key) {
        sendResponse({ ok: false, error: "Not configured — open the extension popup first." });
        return;
      }

      const base = url.replace(/\/mcp\/?$/, "");
      const endpoint = `${base}/openapi.json`;

      try {
        const resp = await fetch(endpoint, {
          headers: { "Authorization": `Bearer ${key}` },
        });

        const text = await resp.text();
        if (!resp.ok) {
          sendResponse({ ok: false, error: `HTTP ${resp.status}: ${text}` });
          return;
        }

        let schema;
        try { schema = JSON.parse(text); } catch { schema = text; }
        sendResponse({ ok: true, schema });
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true; // keep message channel open for async response
  }
  return false;
});
